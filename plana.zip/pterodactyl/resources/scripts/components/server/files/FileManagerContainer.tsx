import React, { useEffect, useState, useCallback } from 'react'; 
import { httpErrorToHuman } from '@/api/http';
import { CSSTransition } from 'react-transition-group';
import Spinner from '@/components/elements/Spinner';
import FileObjectRow from '@/components/server/files/FileObjectRow';
import FileManagerBreadcrumbs from '@/components/server/files/FileManagerBreadcrumbs';
import { FileObject } from '@/api/server/files/loadDirectory';
import NewDirectoryButton from '@/components/server/files/NewDirectoryButton';
import { NavLink, useLocation } from 'react-router-dom';
import Can from '@/components/elements/Can';
import { ServerError } from '@/components/elements/ScreenBlock';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';
import { ServerContext } from '@/state/server';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import MassActionsBar from '@/components/server/files/MassActionsBar';
import UploadButton from '@/components/server/files/UploadButton';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useStoreActions, useStoreState } from '@/state/hooks'; 
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import { FileActionCheckbox } from '@/components/server/files/SelectFileCheckbox';
import { hashToPath } from '@/helpers';
import style from './style.module.css';


import Input from '@/components/elements/Input';
import debounce from 'lodash/debounce';
import { searchServerFiles } from '@/api/server/files/searchFiles';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'; 
import { faSearch } from '@fortawesome/free-solid-svg-icons'; 


const sortFiles = (files: FileObject[]): FileObject[] => {
    const sortedFiles: FileObject[] = files
        .sort((a, b) => a.name.localeCompare(b.name))
        .sort((a, b) => (a.isFile === b.isFile ? 0 : a.isFile ? 1 : -1));
    return sortedFiles.filter((file, index) => index === 0 || file.name !== sortedFiles[index - 1].name);
};

export default () => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const { hash } = useLocation();
    const { data: files, error, mutate } = useFileManagerSwr();
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const { clearFlashes, addError } = useStoreActions((actions) => actions.flashes); 
    const setDirectory = ServerContext.useStoreActions((actions) => actions.files.setDirectory);

    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles);
    const selectedFilesLength = ServerContext.useStoreState((state) => state.files.selectedFiles.length);


    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState<FileObject[] | null>(null);
    const [isSearching, setIsSearching] = useState(false);



    const debouncedSearch = useCallback(
        debounce(async (term: string) => {
            if (term.length < 2 && term.length > 0) { 
                setSearchResults(null);
                setIsSearching(false);
                return;
            }
            if (term.length === 0) {
                setSearchResults(null);
                setIsSearching(false);
                mutate(); 
                return;
            }

            setIsSearching(true);
            clearFlashes('files');
            try {

                const results = await searchServerFiles(id, directory, term);
                setSearchResults(results);
            } catch (error) {
                console.error(error);
                addError({ key: 'files', message: httpErrorToHuman(error) });
                setSearchResults([]);
            } finally {
                setIsSearching(false);
            }
        }, 500),
        [id, directory, addError, clearFlashes, mutate] 
    );


    useEffect(() => {
        clearFlashes('files');
        setSelectedFiles([]);
        setDirectory(hashToPath(hash));
        
        setSearchTerm('');
        setSearchResults(null);
    }, [hash, clearFlashes, setSelectedFiles, setDirectory]);

    useEffect(() => {

        if (searchTerm.length === 0) {
            mutate();
        }
    }, [directory, mutate, searchTerm]);


    useEffect(() => {
        debouncedSearch(searchTerm);
    }, [searchTerm, debouncedSearch]);


    const onSelectAllClick = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedFiles(e.currentTarget.checked ? files?.map((file) => file.name) || [] : []);
    };

    if (error) {
        return <ServerError message={httpErrorToHuman(error)} onRetry={() => mutate()} />;
    }

    return (
        <ServerContentBlock title={'File Manager'} showFlashKey={'files'}>
            <ErrorBoundary>
                <div className={'flex flex-wrap-reverse md:flex-nowrap mb-4'}>
                    <FileManagerBreadcrumbs
                        renderLeft={
                            <FileActionCheckbox
                                type={'checkbox'}
                                css={tw`mx-4 !bg-gray-900`}
                                checked={selectedFilesLength === (files?.length === 0 ? -1 : files?.length)}
                                onChange={onSelectAllClick}
                            />
                        }
                    />
                    {}
                    <div css={tw`relative flex-1 md:flex-none w-full md:w-auto ml-0 md:ml-4 mb-2 md:mb-0`}>
                        <Input
                            type={'text'}
                            placeholder={'Cari file atau folder...'}
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            css={tw`w-full pl-10`} 
                        />
                        <FontAwesomeIcon icon={faSearch} css={tw`absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400`} />
                        {isSearching && <Spinner size={'small'} css={tw`absolute right-3 top-1/2 -translate-y-1/2`} />}
                    </div>
                    {/* ----------------------- */}
                    <Can action={'file.create'}>
                        <div className={style.manager_actions}>
                            <FileManagerStatus />
                            <NewDirectoryButton />
                            <UploadButton />
                            <NavLink to={`/server/${id}/files/new${window.location.hash}`}>
                                <Button>New File</Button>
                            </NavLink>
                        </div>
                    </Can>
                </div>
            </ErrorBoundary>
            {}
            {isSearching && !searchResults ? ( 
                <Spinner size={'large'} centered />
            ) : searchTerm.length > 0 && searchResults !== null ? ( 
                searchResults.length > 0 ? (
                    <CSSTransition classNames={'fade'} timeout={150} appear in>
                        <div>
                            {searchResults.map((file) => (
                                <FileObjectRow key={file.key} file={file} />
                            ))}
                            <MassActionsBar />
                        </div>
                    </CSSTransition>
                ) : (
                    <p css={tw`text-sm text-neutral-400 text-center`}>
                        Tidak ditemukan file atau folder dengan nama "{searchTerm}" di direktori ini atau sub-direktorinya.
                    </p>
                )
            ) : !files ? ( 
                <Spinner size={'large'} centered />
            ) : ( 
                <>
                    {!files.length ? (
                        <p css={tw`text-sm text-neutral-400 text-center`}>Direktori ini kosong.</p>
                    ) : (
                        <CSSTransition classNames={'fade'} timeout={150} appear in>
                            <div>
                                {files.length > 250 && (
                                    <div css={tw`rounded bg-yellow-400 mb-px p-3`}>
                                        <p css={tw`text-yellow-900 text-sm text-center`}>
                                            Direktori ini terlalu besar untuk ditampilkan di browser, membatasi output
                                            hingga 250 file pertama.
                                        </p>
                                    </div>
                                )}
                                {sortFiles(files.slice(0, 250)).map((file) => (
                                    <FileObjectRow key={file.key} file={file} />
                                ))}
                                <MassActionsBar />
                            </div>
                        </CSSTransition>
                    )}
                </>
            )}
            {}
        </ServerContentBlock>
    );
};